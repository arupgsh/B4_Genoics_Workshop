#November 5 2013
#To convert fastq file to fasta file
#!/usr/bin/perl
use strict; use warnings; no warnings 'uninitialized';
use List::Util qw(first max maxstr min minstr reduce shuffle sum);
my $fn=$ARGV[0];
chomp($fn); my $wn=$fn;
open (FILE,"<$fn") or die ("fastq file");
$wn=~s/.fastq/.fa/;
open (WRI,">$wn") or die ("output file");
my @l=(); my $i=0;
while(<FILE>)
	{
		chomp;
		my $h=$_;
		$h=~ s/@/>/;
		my $s=<FILE>; chomp($s);
		$l[$i]=length($s); $i++;
		print WRI "$h\n$s\n";
		<FILE>; <FILE>;
	}
my $max = max(@l);
print "$fn\t$wn\t$max\n";
close (FILE);
close (WRI);
