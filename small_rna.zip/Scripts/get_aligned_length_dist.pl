#May 19 2016  - To get read-length distribution after genomic alignment
#!/usr/bin/perl
use strict; use warnings; no warnings 'uninitialized';
open (AF,"<$ARGV[0]") or die("$!");
open (WRI,">tRNA_align_P1272_v2.txt") or die("$!"); 
#open (WRITE,">Mean_tRNA_align_Subunits.txt") or die("$!");
my %hash=(); my %treads=(); my %rep=();
while(<AF>)
{
	chomp; my $mi=0; my $ti=0; my $j=0; my $sn="";
	my @a=split("\t",$_); chomp(@a); $sn=$a[1]; $sn=~s/\_R[0-9]//g; print STDERR "$sn\t"; $rep{$sn}=0;
	for(my $i=24;$i<=35;$i++) { $hash{$a[1]."\t".$i}=0; }
	open (FH,"<$a[0]") or die("$!");
	while(<FH>)
	{
		chomp;
		my @sp=split("\t",$_); chomp(@sp);
		my $seq=$sp[4]; chomp($seq); my $l=length($seq); $hash{$a[1]."\t".$l}++; $j++;
	} print STDERR "$a[1]\t$j\n"; $treads{$a[1]}=$j;
	close(FH);
}
print WRI "Sample\tReadLen\tPercentage\n";
foreach my $r (keys%hash) { chomp($r); my @in=split("\t",$r); chomp(@in); chomp($hash{$r}); print WRI "$r\t".(($hash{$r}/$treads{$in[0]})*100)."\n"; }
#print WRITE "Sample\tReadLen\tPercentage\n";
#foreach my $t(keys%rep) { chomp($t); for(my $m=18;$m<=35;$m++) { print WRITE "$t\t$m\t".(( (($hash{$t."_R1\t$m"}/$treads{$t."_R1"})*100)+(($hash{$t."_R2\t$m"}/$treads{$t."_R2"})*100))/2)."\n"; } }
close(AF);
