#To split reads 18-35

open (FIL,"<$ARGV[0]") or die ("$!");
open (WR,">$ARGV[1]_18-24mer.fa");
open (WRI,">$ARGV[1]_25-35mer.fa");
open (WRITE,">$ARGV[1]_18-35mer.fa");
my %hash=(); for(my $i=0;$i<77;$i++) { $hash{$i}=0; }
while(<FIL>)
{
	chomp;
	if($_=~/^>/)
	{
		my $s=<FIL>; chomp($s);
		$l=length($s); $hash{$l}++;
		if(($l >= 18) && ($l <= 24)) { print WR "$_\n$s\n"; print WRITE "$_\n$s\n"; }
		elsif(($l >= 25) && ($l <= 35)) { print WRI "$_\n$s\n"; print WRITE "$_\n$s\n"; }
		else { }
	}
}

for(my $j=0;$j<77;$j++) { print "$j\t$hash{$j}\n"; }
