#November 8 2013
#To count number of reads aligned for each read length
#!/usr/bin/perl
use strict; use warnings; no warnings 'uninitialized';
open (FH,"<$ARGV[0]") or die ("alignment file");
open (WRI,">$ARGV[1]") or die ("output file");
my %hash=();
for (my $i=0;$i<=35;$i++)
{
	$hash{$i}=0;
}
while (<FH>)
{
	chomp;
	my @sp=split("\t",$_);
	chomp($sp[4]);
	my $l=length($sp[4]);
	if (exists($hash{$l})) { $hash{$l}++; }
	else{ next;}

}

for (my $j=0;$j<=35;$j++)
{
	print WRI "$j\t$hash{$j}\n";
}
close(FH);
