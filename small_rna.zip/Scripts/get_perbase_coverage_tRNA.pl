#May 24 2016  - To get per base coverage after tRNA alignment
#!/usr/bin/perl
use strict; use warnings; no warnings 'uninitialized';
open (AF,"<$ARGV[0]") or die("$!");
open (WRI,">Perbase_coverage_replicates_subunit_set1.txt") or die("$!"); open (WRITE,">Perbase_coverage_combined_Subunit_set1.txt") or die("$!");
#open (CON,">Uniq_tRNA_by_seq_perbase.txt");
my %hash=(); my %trna_len=(); my %rep=(); my %treads=(); my %store=();
open (TL,"</neoblast/Das_Data/Ramanuj_tRNA_data/tRNA/Mouse/mouse_tRNA.fa.fai") or die("$!");
while(<TL>) { chomp; my @z=split("\t",$_); chomp(@z); $trna_len{$z[0]}=$z[1]; }
while(<AF>)
{
	chomp; my $mi=0; my $ti=0; my $k=0; my $sn="";
	my @a=split("\t",$_); chomp(@a); $sn=$a[1]; $sn=~s/\_R[0-9]//g; print STDERR "$sn\t"; $rep{$sn}=0;
	foreach my $x(keys%trna_len) { chomp($x); for(my $i=0;$i<$trna_len{$x};$i++) { $hash{$a[1]."\t".$x."\t".$i}=0; } }
	open (FH,"<$a[0]") or die("$!");
	while(<FH>)
	{
		chomp;
		my @sp=split("\t",$_); chomp(@sp);
		my $sl=length($sp[4]); my $rstart=$sp[3]; my $rend=($rstart+$sl); $k++;
		for(my $j=$rstart;$j<=$rend;$j++) { $hash{$a[1]."\t".$sp[2]."\t".$j}++; }
	} $treads{$a[1]}=$k; print "$k\n";
	close(FH);
}
foreach my $r(keys%hash) { chomp($r); my @e=split("\t",$r); chomp(@e); print WRI "$r\t".(($hash{$r}/$treads{$e[0]})*100)."\n"; }
foreach my $q(keys%rep) { chomp($q); foreach my $tr(keys%trna_len) { chomp($tr); for(my $kl=0;$kl<$trna_len{$tr};$kl++) { my $r1=$q."_R1"; my $r2=$q."_R2"; my $v=(((($hash{"$r1\t$tr\t$kl"}/$treads{$r1})*100)+(($hash{"$r2\t$tr\t$kl"}/$treads{$r2})*100))/2); print WRITE "$q\t$tr\t$kl\t$v\n"; $store{"$q\t$tr\t$kl"}=$v; } } }
close(AF);
