#!/bin/bash
#After adapter trimming

trim=$1; na=$2;  #Adapret rimmed file - trim & Filename prefix na
rrna="./rRNA/Index_rRNA_MusMusculus"; 
gindex="./Genome/mouse";
mir="./Index_mmu_miRNAs/mmu_mirna_extended";
trans="./Refseq_Transcriptome/MusMusculus_mRNA_Seq"; 
ctrna="./tRNA/clustered_50bps_tRNAs_mm10";
nc="./ncRNA/MusMusculus_ncRNA_lncrnadb"; 
ctids="./combined.ids";
#To rRNA

echo "Aligning to rRNA";
declare -a injobs

nohup /usr/bin/bowtie -f -v 2 -p 20 $rrna --un rRNA_removed_reads.fa $trim To_rRNA_v2.aln > rrna.log &

injobs+=($!)
for i in ${injobs[@]}; do
    wait $i
done

echo "rRNA alignment is done";

/bin/cat rrna.log

#Splitting Reads into different length
/usr/bin/perl split_reads_bylen.pl rRNA_removed_reads.fa $na > after_trim_len.txt

all=$na; all+="_18-35mer.fa"; ini=$na; ini+="_18-24mer.fa"; en=$na; en+="_25-35mer.fa"; on=$na; on+="_tRNA_25-35mer.txt"; onc=$na; onc+="_ctRNA_25-35mer.txt";

echo "Number of Reads"
/bin/grep -c "^>" $na* | /usr/bin/awk -F ":" '{print $1"\t"$2}' | /bin/sed 's:.fa::g'

#Mapping to genome

echo "Genome alignment started";
echo "#18-35mer to genome" >> galign.log

declare -a ag

nohup /usr/bin/bowtie -f -v 2 -p 20 $gindex $all To_genome_v2_18-35.aln >> galign.log &

ag+=($!)
for i in ${ag[@]}; do
    wait $i
done

echo "#18-24mer to genome" >> galign.log

declare -a sg

nohup /usr/bin/bowtie -f -v 2 -p 20 $gindex $ini To_genome_v2_18-24.aln >> galign.log &

sg+=($!)
for i in ${sg[@]}; do wait $i; done

echo "#25-35mer to genome" >> galign.log

declare -a tg

nohup /usr/bin/bowtie -f -v 2 -p 20 $gindex $en To_genome_v2_25-35.aln >> galign.log &

tg+=($!)
for i in ${tg[@]}; do wait $i; done

echo "Alignment done";

/bin/cat galign.log | /usr/bin/awk '{if($1 == "#To" || /reported/) print $0}'

#Analysis of 18-24mer data

echo "18-24mer analysis started";

#To miRNA

echo "#To miRNA " >> log_18-24mer

declare -a mi18

nohup /usr/bin/bowtie -f -v 2 -p 20 $mir --un rRNA_miRNA_minus_reads_18-24mer.fa $ini 18-24mer_to_miRNA_v2.aln >> log_18-24mer 

mi18+=($!)
for i in ${mi18[@]}; do wait $i; done

echo "#To tRNA" >> log_18-24mer

declare -a tr18

nohup /usr/bin/bowtie -f -v 2 -p 20 $tRNA --un rRNA_miRNA_tRNA_minus_reads_18-24mer.fa rRNA_miRNA_minus_reads_18-24mer.fa 18-24mer_to_tRNA_v2.aln >> log_18-24mer &

tr18+=($!)
for i in ${tr18[@]}; do wait $i; done

echo "#To transcriptome" >> log_18-24mer

declare -a trans18

nohup /usr/bin/bowtie -f -v 2 -p 20 $trans --un rRNA_miRNA_tRNA_Trans_minus_reads_18-24mer.fa rRNA_miRNA_tRNA_minus_reads_18-24mer.fa 18-24mer_to_Trans_v2.aln >> log_18-24mer &

trans18+=($!)
for i in ${trans18[@]}; do wait $i; done

echo "#To lncRNA" >> log_18-24mer

declare -a ln18

nohup /usr/bin/bowtie -f -v 2 -p 20 $nc --un rRNA_miRNA_tRNA_Trans_ncRNA_minus_reads_18-24mer.fa rRNA_miRNA_tRNA_Trans_minus_reads_18-24mer.fa 18-24mer_to_lncRNA_v2.aln >> log_18-24mer &

ln18+=($!)
for i in ${ln18[@]}; do wait $i; done

echo "miRNA,tRNA,lncRNA,transcriptome is done";

echo "18-24mer analysis done"

/bin/cat log_18-24mer

echo ""

/bin/cat log_18-24mer | /usr/bin/awk '{if($1 == "#To" || /reported/) print $0}'

#25-35mer analysis

echo "25-35mer Analysis started";

#To tRNA

#To combined tRNA list

echo "#To combined tRNA dataset" >> log_25-35mer

declare -a ctr25

nohup /usr/bin/bowtie -f -v 2 -p 20 --un rRNA_tRNA_minus_reads_25-35mer1.fa $ctrna $en 25-35mer_to_ctRNA_v2.aln >> log_25-35mer &

ctr25+=($!)
for i in ${ctr25[@]}; do wait $i; done

/usr/bin/perl find_count.pl 25-35mer_to_ctRNA_v2.aln $ctids > $onc

echo "#To transcriptome 25-35mer" >> log_25-35mer

declare -a trans25

nohup /usr/bin/bowtie -f -v 2 -p 20 $trans --un rRNA_tRNA_Trans_minus_reads_25-35mer.fa rRNA_tRNA_minus_reads_25-35mer.fa 25-35mer_to_Trans_v2.aln >> log_25-35mer &

trans25+=($!)
for i in ${trans25[@]}; do wait $i; done

echo "#To lncRNA 25-35mer" >> log_25-35mer

declare -a ln25

nohup /usr/bin/bowtie -f -v 2 -p 20 $nc --un rRNA_tRNA_Trans_lncRNA_minus_reads_25-35mer.fa rRNA_tRNA_Trans_minus_reads_25-35mer.fa 25-35mer_to_ncRNA_v2.aln >> log_25-35mer &

ln25+=($!)
for i in ${ln25[@]}; do wait $i; done

echo "tRNA,lncRNA,transcriptome is done";

echo "25-35mer analysis is done";

/bin/cat log_25-35mer

echo ""

/bin/cat log_25-35mer | /usr/bin/awk '{if($1 == "#To" || /reported/) print $0}'

echo "Analysis Done!!"
#Done
