#Sept 1 2017
#To combine tsRNA pull down data
#!/usr/bin/perl

my %mcc1=(); my %mcc2=(); my %ms=(); my %skin=();
open (ONE,"<$ARGV[0]");
while(<ONE>) { chomp; my @a=split("\t",$_); chomp(@a); $mcc1{$a[0]}=$a[-1]; }
open (TWO,"<$ARGV[1]");
while(<TWO>) { chomp; my @b=split("\t",$_); chomp(@b); $mcc2{$b[0]}=$b[-1]; }
open (TREE,"<$ARGV[2]");
while(<TREE>) { chomp; my @c=split("\t",$_); chomp(@c); $ms{$c[0]}=$c[-1]; }
open (FOUR,"<$ARGV[3]");
while(<FOUR>) { chomp; my @d=split("\t",$_); chomp(@d); $skin{$d[0]}=$d[-1]; }
foreach my $r(keys%mcc1) 
{
	chomp($r);
	my $sum=($mcc1{$r}+$mcc2{$r}+$ms{$r}+$skin{$r});
	if($sum > 10) { print "$r\t".($mcc1{$r}+1)."\t".($mcc2{$r}+1)."\t".($ms{$r}+1)."\t".($skin{$r}+1)."\n"; } else { }
}
