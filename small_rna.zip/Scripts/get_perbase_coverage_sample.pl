#May 24 2016  - To get per base coverage after tRNA alignment sample wise
#!/usr/bin/perl
use strict; use warnings; no warnings 'uninitialized';
open (AF,"<$ARGV[0]") or die("$!");
open (WRI,">Perbase_coverage_Samplewise_MC.txt") or die("$!"); #open (WRITE,">Set1_Perbase_coverage_Samplewise_subunit_rep.txt");
open (RS,">Samplewise_readstart_MC.txt") or die("$!"); 
#open (RAW,">Perbase_coverage_Samplewise_R2_Igf2bp1_raw.txt") or die("$!");
my %hash=(); my %trna_len=(); my %rep=(); my %treads=(); my %store=();
while(<AF>)
{
	chomp; my $mi=0; my $ti=0; my $k=0; my $sn="";
	my @a=split("\t",$_); chomp(@a); $sn=$a[1]; $sn=~s/\_R[0-9]//g; print STDERR "$sn\t"; $rep{$sn}=0;
	for(my $i=0;$i<=110;$i++) { $hash{$a[1]."\t".$i}=0; }
	open (FH,"<$a[0]") or die("$!");
	while(<FH>)
	{
		chomp;
		my @sp=split("\t",$_); chomp(@sp);
		my $sl=length($sp[4]); my $rstart=$sp[3]; my $rend=($rstart+$sl); $k++; $trna_len{$a[1]."\t".$rstart}++;
		for(my $j=$rstart;$j<=$rend;$j++) { $hash{$a[1]."\t".$j}++; }
	} $treads{$a[1]}=$k; print "$k\n";
	close(FH);
}
foreach my $r(keys%hash) { chomp($r); my @in=split("\t",$r); chomp(@in); print WRI "$r\t".(($hash{$r}/$treads{$in[0]})*100)."\n"; } 
foreach my $u(keys%trna_len) { chomp($u); my @ai=split("\t",$u); chomp(@ai); print RS "$u\t".(($trna_len{$u}/$treads{$ai[0]})*100)."\n"; }
#foreach my $q(keys%rep) { chomp($q); for(my $kl=0;$kl<=110;$kl++) { my $r1=$q."_R1"; my $r2=$q."_R2"; my $v=(((($hash{"$r1\t$kl"}/$treads{$r1})*100)+(($hash{"$r2\t$kl"}/$treads{$r2})*100))/2); my $v1=((($hash{"$r1\t$kl"}/($treads{$r1}*1000000))+($hash{"$r2\t$kl"}/($treads{$r2}*1000000)))/2); print WRI "$q\t$kl\t$v\n"; print RAW "$q\t$kl\t$v1\n"; $store{"$q\t$kl"}=$v; } }
close(AF);
