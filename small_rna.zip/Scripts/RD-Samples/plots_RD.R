Sys.setenv(http_proxy="http://proxy.ncbs.res.in:3128")
Sys.setenv(https_proxy="https://proxy.ncbs.res.in:3128")
source("http://bioconductor.org/biocLite.R")
setwd("/neoblast/Das_Data/Ramanuj_tRNA_data/tRNA/Mouse/Plots_tsRNA_Paper")
library("ggExtra", lib.loc="~/R/x86_64-pc-linux-gnu-library/3.0")
library("ggExtra", lib.loc="~/R/x86_64-pc-linux-gnu-library/3.0")
library("colorspace", lib.loc="/usr/local/lib/R/site-library")
library("codetools", lib.loc="/usr/lib/R/library")
library("corrplot", lib.loc="/usr/local/lib/R/site-library")
library("extrafontdb", lib.loc="/usr/local/lib/R/site-library")
library("extrafont", lib.loc="/usr/local/lib/R/site-library")
library("fheatmap", lib.loc="/usr/local/lib/R/site-library")
library("foreach", lib.loc="/usr/local/lib/R/site-library")
library("g.data", lib.loc="/usr/lib/R/site-library")
library("gdata", lib.loc="/usr/local/lib/R/site-library")
library("gdata", lib.loc="/usr/lib/R/site-library")
library("ggExtra", lib.loc="/usr/local/lib/R/site-library")
library("ggplot2", lib.loc="/usr/local/lib/R/site-library")
library("ggplot2", lib.loc="/usr/lib/R/library")
library("gplots", lib.loc="/usr/local/lib/R/site-library")
library("graph", lib.loc="/usr/local/lib/R/site-library")
library("graphics", lib.loc="/usr/lib/R/library")
library("grid", lib.loc="/usr/lib/R/library")
library("gridBase", lib.loc="/usr/local/lib/R/site-library")
library("gridExtra", lib.loc="/usr/lib/R/site-library")
library("gtable", lib.loc="/usr/local/lib/R/site-library")
library("gtools", lib.loc="/usr/local/lib/R/site-library")
library("gtools", lib.loc="/usr/lib/R/site-library")
library("igraph", lib.loc="/usr/local/lib/R/site-library")
library("IRanges", lib.loc="/usr/local/lib/R/site-library")
library("lattice", lib.loc="/usr/lib/R/library")
library("latticeExtra", lib.loc="/usr/local/lib/R/site-library")
library("pheatmap", lib.loc="/usr/local/lib/R/site-library")
library("plotrix", lib.loc="/usr/local/lib/R/site-library")
library("plyr", lib.loc="/usr/lib/R/site-library")
library("R.methodsS3", lib.loc="/usr/local/lib/R/site-library")
library("RColorBrewer", lib.loc="/usr/local/lib/R/site-library")
library("Rcpp", lib.loc="/usr/local/lib/R/site-library")
library("Rcpp", lib.loc="/usr/lib/R/site-library")
library("RCurl", lib.loc="/usr/lib/R/site-library")
library("reshape", lib.loc="/usr/lib/R/library")
library("reshape2", lib.loc="/usr/lib/R/library")
library("RSQLite", lib.loc="/usr/local/lib/R/site-library")
library("VennDiagram", lib.loc="/usr/local/lib/R/site-library")
library("whisker", lib.loc="/usr/local/lib/R/site-library")

#To plot read length before aligning to genome. After adapter trimming.

readlen_rd<-read.table("BeforeAlignment_RL_RDsample.txt",head=T)
readlen_rd_m<-melt(readlen_rd,id.vars=c("Sample","ReadLen"))
ggplot(readlen_rd_m,aes(x=ReadLen,y=value,colour=Sample))+geom_line(lwd=1) + geom_point(shape=21, fill="white")+theme_bw()+scale_colour_manual(values=c("red","red","blue","blue","green","green"))+xlab("Read Length")+ylab("Percentage of Reads")+theme(legend.position="top")+scale_x_continuous(limits = c(0,52),breaks=seq(0,52,5))+scale_y_continuous(limits=c(0,28),breaks=seq(0,28,by=5)) # With replicates_values intact

#Mean of replicates
mrl<-read.table("Mean_RL_RDsample.txt",head=T)
mrlm<-melt(mrl,id.vars=c("Sample","ReadLen"))
ggplot(mrlm,aes(x=ReadLen,y=value,colour=Sample))+geom_line(lwd=1) + geom_point(shape=21, fill="white")+theme_bw()+xlab("Read Length")+ylab("Percentage of Reads")+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_x_continuous(limits = c(0,52),breaks=seq(0,52,5))+scale_y_continuous(limits=c(0,25),breaks=seq(0,25,by=5))

#i)51nt length

ggplot(mrlm,aes(x=ReadLen,y=value,colour=Sample))+geom_line(lwd=1.1) + geom_point(shape=19, fill="white")+theme_bw()+xlab("Read Length")+ylab("Percentage of Reads")+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_x_continuous(limits = c(1,52),breaks=seq(1,52,3))+scale_y_continuous(limits=c(0,25),breaks=seq(0,25,by=5))+scale_colour_manual(values = c( "Wnt3a"="#cccccc","S+LIF"="#636363", "RA_treated"="#252525"))

#ii) 18-35 length

ggplot(mrlm,aes(x=ReadLen,y=value,colour=Sample))+geom_line(lwd=1.1) + geom_point(shape=19, fill="white")+theme_bw()+xlab("Read Length")+ylab("Percentage of Reads")+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_x_continuous(limits = c(18,35),breaks=seq(18,35,1))+scale_y_continuous(limits=c(0,25),breaks=seq(0,25,by=5))+scale_colour_manual(values = c( "Wnt3a"="#cccccc","S+LIF"="#636363", "RA_treated"="#252525"))

#iii) 25-35mer length

ggplot(mrlm,aes(x=ReadLen,y=value,colour=Sample))+geom_line(lwd=1.1) + geom_point(shape=19, fill="white")+theme_bw()+xlab("Read Length")+ylab("Percentage of Reads")+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_x_continuous(limits = c(25,35),breaks=seq(25,35,1))+scale_y_continuous(limits=c(0,25),breaks=seq(0,25,by=5))+scale_colour_manual(values = c( "Wnt3a"="#cccccc","S+LIF"="#636363", "RA_treated"="#252525"))


#Aligned length distribution
mal<-read.table("Mean_ARL_RDsample.txt",head=T)
malm<-melt(mal,id.vars=c("Sample","ReadLen"))
ggplot(malm,aes(x=ReadLen,y=value,colour=Sample))+geom_line(lwd=1) + geom_point(shape=21, fill="white")+theme_bw()+xlab("Read Length")+ylab("Percentage of Reads")+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_x_continuous(limits = c(18,35),breaks=seq(18,35,1))+scale_y_continuous(limits=c(0,30),breaks=seq(0,30,by=5))

#Edited code for sample Aligned length

ggplot(malm,aes(x=ReadLen,y=value,colour=Sample))+geom_line(lwd=1.1) + geom_point(shape=19, fill="white")+theme_bw()+xlab("Read Length")+ylab("Percentage of Reads")+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_x_continuous(limits = c(18,35),breaks=seq(18,35,1))+scale_y_continuous(limits=c(0,30),breaks=seq(0,30,by=5))+scale_colour_manual(values = c( "Wnt3a"="#cccccc","S+LIF"="#636363", "RA_treated"="#252525"))

#Split as 18-24 & 25-35
ggplot(malm,aes(x=ReadLen,y=value,colour=Sample))+geom_line(lwd=1.1) + geom_point(shape=19, fill="white")+theme_bw()+xlab("Read Length")+ylab("Percentage of Reads")+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_x_continuous(limits = c(18,24),breaks=seq(18,24,1))+scale_y_continuous(limits=c(0,30),breaks=seq(0,30,by=5))+scale_colour_manual(values = c( "Wnt3a"="#cccccc","S+LIF"="#636363", "RA_treated"="#252525"))
ggplot(malm,aes(x=ReadLen,y=value,colour=Sample))+geom_line(lwd=1.1) + geom_point(shape=19, fill="white")+theme_bw()+xlab("Read Length")+ylab("Percentage of Reads")+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_x_continuous(limits = c(25,35),breaks=seq(25,35,1))+scale_y_continuous(limits=c(0,30),breaks=seq(0,30,by=5))+scale_colour_manual(values = c( "Wnt3a"="#cccccc","S+LIF"="#636363", "RA_treated"="#252525"))

#tRNA alignment length distribution
trna_al<-read.table("Mean_tRNA_align_RDsample.txt",head=T)
trna_alm<-melt(trna_al,id.vars=c("Sample","ReadLen"))
ggplot(trna_alm,aes(x=ReadLen,y=value,colour=Sample))+geom_line(lwd=1.1) + geom_point(shape=19, fill="white")+theme_bw()+xlab("Read Length")+ylab("Percentage of Reads")+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_x_continuous(limits = c(18,35),breaks=seq(18,35,1))+scale_y_continuous(limits=c(0,30),breaks=seq(0,30,by=5))+scale_colour_manual(values = c( "Wnt3a"="#cccccc","S+LIF"="#636363", "RA_treated"="#252525"))

#tRNA alignment percentage across condition
trna_p<-read.table("genomic_percentage_RD.txt",head=TRUE)
trna_pm<-melt(trna_p,id.vars="Sample")
ggplot(trna_pm,aes(y=value,x=reorder(Sample, value)))+xlab("Conditions")+ylab("Percentage mapped to tRNA")+geom_bar(stat="identity",width=0.5,fill="gray60")+scale_y_continuous(limits=c(0,65),breaks=seq(0,65,by=5))+theme_bw()+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_colour_manual(values = c( "Wnt3a"="#cccccc","S+LIF"="#636363", "RA"="#252525"))

#Mismatch percentage tRNA for different samples
mis_perc<-read.table("tRNA_mismatch.txt",head=T )
mis_match<-melt(mis_perc,id.vars=c("Sample","Mismatch"))
#ggplot(mis_match,aes(y=value,x=Sample,fill=Mismatch))+xlab("Conditions")+ylab("Percentage mapped to tRNA")+geom_bar(stat="identity",width=0.5,position="dodge")+scale_y_continuous(limits=c(0,65),breaks=seq(0,65,by=5))+theme_bw()+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))
#ggplot(mis_match,aes(y=value,x=Mismatch,fill=Sample))+xlab("Number of mismatch")+ylab("Percentage mapped to tRNA")+geom_bar(stat="identity",width=0.5,position="dodge")+scale_y_continuous(limits=c(0,65),breaks=seq(0,65,by=5))+theme_bw()+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))

ggplot(mis_match,aes(y=value,x=reorder(Sample,value),fill=Mismatch))+xlab("Conditions")+ylab("Percentage mapped to tRNA")+geom_bar(stat="identity",width=0.5,position="dodge")+scale_y_continuous(limits=c(0,65),breaks=seq(0,65,by=5))+theme_bw()+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_fill_manual(values = c( "v0"="#cccccc","v1"="#636363", "v2"="#252525"))

#plotting sample wise tRNA distribution as percentage 

rd_sample_dist<-read.table("Perbase_coverage_Samplewise.txt",head =T )
rd_sample_dist_m<-melt(rd_sample_dist,id.vars=c("Sample","Position"))
ggplot(rd_sample_dist_m,aes(x=Position,y=value,color=Sample))+geom_area(aes(fill=Sample,stat="identity"),alpha=0.6)+facet_wrap(~ Sample, ncol=1)+theme_bw()+xlab("tRNA Position")+ylab("Percentage of reads mapped")+scale_x_continuous(limits=c(0,80),breaks=seq(0,80,by=4))+guides(color=FALSE,fill=FALSE)+theme(axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+geom_vline(xintercept=c(33), linetype="dashed")+geom_vline(xintercept=c(35), linetype="dashed")+annotate(geom="text", x=36, y=70.0, label="Anticodon", color="black", fontface="italic")+geom_segment(aes(x = 34, y = 11, xend = 34, yend = 10), arrow = arrow(type="closed",ends="last",length = unit(0.3, "cm")),col="black")

#Plotting sameple wise tRNA distribution as percentage with bar plot
sub<-subset(rd_sample_dist_m, Position >= 32 & Position <= 35, select=c(Sample:value))

#ggplot(rd_sample_dist_m,aes(x=Position,y=value,color=Sample))+geom_area(aes(fill=Sample,stat="identity"),alpha=0.8)+facet_wrap(~ Sample, ncol=1)+theme_bw()+xlab("tRNA Position")+ylab("Percentage of reads mapped")+scale_x_continuous(limits=c(0,80),breaks=seq(0,80,by=4))+guides(color=FALSE,fill=FALSE)+theme(axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+geom_vline(xintercept=c(31), linetype="dashed")+geom_vline(xintercept=c(35), linetype="dashed")+annotate(geom="text", x=36, y=80.0, label="Anticodon", color="black", fontface="italic")+geom_segment(aes(x = 33, y = 81, xend = 33, yend = 80), arrow = arrow(type="closed",ends="last",length = unit(0.3, "cm")),col="black")+geom_bar(data=sub,aes(x=Position,y=value),stat="identity",alpha=0.2,col="black")
#ggplot(rd_sample_dist_m,aes(x=Position,y=value,color=Sample))+geom_area(aes(fill=Sample,stat="identity"),alpha=0.8)+facet_wrap(~ Sample, ncol=1)+theme_bw()+xlab("tRNA Position")+ylab("Percentage of reads mapped")+scale_x_continuous(limits=c(0,80),breaks=seq(0,80,by=4))+guides(color=FALSE,fill=FALSE)+theme(axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+geom_vline(xintercept=c(31), linetype="dashed")+geom_vline(xintercept=c(35), linetype="dashed")+annotate(geom="text", x=34, y=92, label="Anticodon", color="black", fontface="italic")+geom_segment(aes(x = 33, y = 77, xend = 33, yend = 76), arrow = arrow(type="closed",ends="last",length = unit(0.28, "cm")),col="black")+geom_bar(data=sub,aes(x=Position,y=value),stat="identity",alpha=0.2,col="black")

ggplot(rd_sample_dist_m,aes(x=Position,y=value))+geom_area(aes(fill=Sample,stat="identity"),alpha=0.6)+facet_wrap(~ Sample, ncol=1)+theme_bw()+xlab("tRNA Position")+ylab("Percentage of reads mapped")+scale_x_continuous(limits=c(0,80),breaks=seq(0,80,by=4))+guides(color=FALSE,fill=FALSE)+theme(axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+geom_vline(xintercept=c(31), linetype="dashed")+geom_vline(xintercept=c(35), linetype="dashed")+annotate(geom="text", x=34, y=92, label="Anticodon", color="black", fontface="italic")+geom_segment(aes(x = 33, y = 77, xend = 33, yend = 76), arrow = arrow(type="closed",ends="last",length = unit(0.28, "cm")),col="black")+scale_fill_manual(values = c( "Wnt3a"="#cccccc","S+LIF"="#636363", "RA_treated"="#252525"))
ggplot(rd_sample_dist_m,aes(x=Position,y=value))+geom_area(aes(fill=Sample,stat="identity"),alpha=0.6)+facet_wrap(~ Sample, ncol=1)+theme_bw()+xlab("tRNA Position")+ylab("Percentage of reads mapped")+scale_x_continuous(limits=c(0,80),breaks=seq(0,80,by=4))+guides(color=FALSE,fill=FALSE)+theme(axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+geom_vline(xintercept=c(32), linetype="dashed")+geom_vline(xintercept=c(36), linetype="dashed")+annotate(geom="text", x=34, y=92, label="Anticodon", color="red", fontface="italic")+geom_segment(aes(x = 33, y = 77, xend = 33, yend = 76), arrow = arrow(type="closed",ends="last",length = unit(0.28, "cm")),col="black")+scale_fill_manual(values = c( "Wnt3a"="#cccccc","S+LIF"="#636363", "RA_treated"="#252525"))


#Anticodon position
# 1 32
#148 33
#217 34
#66 35
#1 36

ac_pos<-read.table("Anticodon_position_tRNAs_all",head=TRUE)
ggplot(ac_pos,aes(x=ac_pos$Position,y=((ac_pos$tRNAs/433)*100)))+geom_bar(stat="identity",width=0.7,fill="gray60")+theme_bw()+scale_y_continuous(limits=c(0,55),breaks=seq(0,55,by=5))+theme_bw()+theme(axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+xlab("Anticodon start")+ylab("Percentage of tRNA")


#Processing information RD sample

#i)Wnt

processing_rd<-read.table("rd_sample_processing.txt",head=T)
ggplot(processing_rd,aes(x=factor(""),fill=Category,y=Percentage))+geom_bar(width=1,stat="identity")+coord_polar(theta="y")+xlab("")+ylab("")+theme_bw()+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_fill_manual(values = c( "After-Anticodon"="#deebf7","Anticodon"="#9ecae1", "Pre-Anticodon"="#3182bd"))

#ii)S+LIF

processing_rd<-read.table("rd_sample_processing.txt",head=T)
ggplot(processing_rd,aes(x=factor(""),fill=Category,y=Percentage))+geom_bar(width=1,stat="identity")+coord_polar(theta="y")+xlab("")+ylab("")+theme_bw()+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_fill_manual(values = c( "After-Anticodon"="#deebf7","Anticodon"="#9ecae1", "Pre-Anticodon"="#3182bd"))

#iii)RA

processing_rd<-read.table("rd_sample_processing.txt",head=T)
ggplot(processing_rd,aes(x=factor(""),fill=Category,y=Percentage))+geom_bar(width=1,stat="identity")+coord_polar(theta="y")+xlab("")+ylab("")+theme_bw()+theme(legend.position="top",axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))+scale_fill_manual(values = c( "After-Anticodon"="#deebf7","Anticodon"="#9ecae1", "Pre-Anticodon"="#3182bd"))

