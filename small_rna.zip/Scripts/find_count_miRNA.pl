# November 6 2013
# To find reads mapped to particular miRNA
#!/usr/bin/perl
use strict; use warnings; no warnings 'uninitialized';
my $fn=$ARGV[0];
my $id=$ARGV[1]; chomp($fn); chomp($id);
open (FH,"<$id") or die ("id file");
my %hash=();
while (<FH>)
{
	chomp;
	for (my $i=18;$i<=24;$i++)
	{
		my $key=($_."\t".$i);
		$hash{$key}=0;
	}
}
open (FIL,"<$fn") or die ("alignment file");
while (<FIL>)
{
	chomp;
	my @sp=split("\t",$_);
	chomp($sp[2]); chomp($sp[4]);
	my $l=length($sp[4]);
	my $s=($sp[2]."\t".$l);
	if (exists($hash{$s}))
	{
		$hash{$s}++;
	}
}
open (FILE,"<$id");
while (<FILE>)
{
	chomp;
	print "$_\t"; my $sum=0;
	for (my $j=18;$j<=24;$j++)
	{
		my $k=($_."\t".$j);
		print "$hash{$k}\t";
		$sum+=$hash{$k};
	}
	print "$sum\n";
}
