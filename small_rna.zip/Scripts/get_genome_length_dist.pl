#May 19 2016  - To get read-length distribution before genomic alignment
#!/usr/bin/perl
use strict; use warnings; no warnings 'uninitialized';
open (AF,"<$ARGV[0]") or die("$!");
open (WRI,">BeforeAlignment_RL_Primet.txt") or die("$!"); #open (WRITE,">Mean_RL_Monosome.txt") or die("$!");
my %hash=(); my %sample=(); my %treads=(); my %rep=();
while(<AF>)
{
	chomp; my $mi=0; my $ti=0; my $j=0; my $sn="";
	my @a=split("\t",$_); chomp(@a); $sn=$a[1]; $sn=~s/\_R[0-9]//g; print STDERR "$sn\n"; $rep{$sn}=0;
	for(my $i=17;$i<=36;$i++) { $hash{$a[1]."\t".$i}=0; }
	open (FH,"<$a[0]") or die("$!");
	while(<FH>)
	{
		chomp;
		if($_=~/^>/g)
		{
			my $seq=<FH>; chomp($seq); my $l=length($seq); $hash{$a[1]."\t".$l}++; $j++;
			if(($l >= 18) && ($l <=24)) { $mi++; } elsif(($l >= 25) && ($l <=35)) { $ti++; } else { }
		} 
	} print STDERR "$a[1]\t$mi\t$ti\t$j\n"; $treads{$a[1]}=$j;
	my $tot=$mi+$ti; my $mp=(($mi/$tot)*100); my $tp=(($ti/$tot)*100); $sample{$a[1]}=("$mp\t$tp");
	close(FH);
}
print WRI "Sample\tReadLen\tPercentage\n"; #print WRITE "Sample\tReadLen\tPercentage\n";
foreach my $r (keys%hash) { chomp($r); my @in=split("\t",$r); chomp(@in); chomp($hash{$r}); print WRI "$r\t".(($hash{$r}/$treads{$in[0]})*100)."\n"; }
#foreach my $t(keys%rep) { chomp($t); for(my $m=18;$m<=36;$m++) { print WRITE "$t\t$m\t".(( (($hash{$t."_R1\t$m"}/$treads{$t."_R1"})*100)+(($hash{$t."_R2\t$m"}/$treads{$t."_R2"})*100))/2)."\n"; } }
print "Sample\tRL18-24\tRL25-35\n"; foreach my $w(keys%sample) { chomp($w); print "$w\t$sample{$w}\n"; }
close(AF);
